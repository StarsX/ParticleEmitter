//--------------------------------------------------------------------------------------
// Copyright (c) XU, Tianchen. All rights reserved.
//--------------------------------------------------------------------------------------

#pragma once

#include "XUSGPipelineLayout.h"
#include "XUSGGraphicsState.h"
#include "XUSGComputeState.h"
#include "XUSGResource.h"
#include "XUSGDescriptor.h"
